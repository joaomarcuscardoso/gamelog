package com.udesc.padroesdeprojeto.gamelog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamelogApplicationTests {

	@Test
	void contextLoads() {
	}

}
